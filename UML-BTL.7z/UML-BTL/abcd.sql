﻿CREATE DATABASE BTL_UML
GO

-- Sử dụng cơ sở dữ liệu
USE BTL_UML
GO

CREATE TABLE TaiKhoan (
    TaiKhoan NVARCHAR(50) PRIMARY KEY,
    MatKhau NVARCHAR(50) NOT NULL
);
GO

-- Tạo bảng LoaiGauBong để lưu các loại gấu bông
CREATE TABLE LoaiGauBong (
    MaLoai INT PRIMARY KEY,
    TenLoai NVARCHAR(50) NOT NULL
);
GO

-- Tạo bảng GauBong để lưu thông tin về các sản phẩm gấu bông
CREATE TABLE GauBong (
    MaGauBong INT PRIMARY KEY,
    TenGauBong NVARCHAR(100) NOT NULL,
    MaLoai INT,
    SoLuong INT,
    DonGia DECIMAL(18, 0),
    FOREIGN KEY (MaLoai) REFERENCES LoaiGauBong(MaLoai) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

-- Tạo bảng KhachHang để lưu thông tin khách hàng
CREATE TABLE KhachHang (
    MaKH INT PRIMARY KEY,
    TenKH NVARCHAR(100) NOT NULL,
    DiaChi NVARCHAR(200),
    SDT NVARCHAR(20),
    Email NVARCHAR(100)
);
GO

-- Tạo bảng NhanVien để lưu thông tin NV
CREATE TABLE NhanVien (
    MaNV INT PRIMARY KEY ,
    TenNV NVARCHAR(100) NOT NULL,
    GioiTinh NVARCHAR(10) NOT NULL,
    DiaChi NVARCHAR(200),
    SDT NVARCHAR(20)
);
GO

-- Tạo bảng NhaCC để lưu thông tin NCC (Nhà cung cấp gấu bông)
CREATE TABLE NhaCC (
    MaNCC INT PRIMARY KEY,
    TenNCC NVARCHAR(100) NOT NULL,
    SDT NVARCHAR(20),
    DiaChi NVARCHAR(200)
);
GO

SELECT * FROM NhaCC;

-- Tạo bảng DonNhap để lưu thông tin về đơn hàng nhập gấu bông
CREATE TABLE HoaDonNhap (
    MaHDN INT PRIMARY KEY ,
    MaNCC INT FOREIGN KEY REFERENCES NhaCC(MaNCC),
    MaNV INT FOREIGN KEY REFERENCES NhanVien(MaNV),
    MaGauBong INT FOREIGN KEY REFERENCES GauBong(MaGauBong),
    NgayNhap DATETIME NOT NULL,
    ThanhTien FLOAT NOT NULL
);
GO

-- Xóa bảng HoaDonNhap

-- Tạo bảng DonBan để lưu thông tin về đơn hàng bán gấu bông
CREATE TABLE HoaDonBan (
    MaHDB INT PRIMARY KEY ,
    MaNV INT FOREIGN KEY REFERENCES NhanVien(MaNV),
    MaKH INT FOREIGN KEY REFERENCES KhachHang(MaKH),
    MaGauBong INT FOREIGN KEY REFERENCES GauBong(MaGauBong),
    NgayBan DATETIME NOT NULL,
    ThanhTien FLOAT NOT NULL
);
GO

-- Tạo bảng ChiTietDonNhap để lưu chi tiết của từng đơn hàng nhập
CREATE TABLE ChiTietHDN (
    MaChiTietDN INT PRIMARY KEY ,
    MaGauBong INT FOREIGN KEY REFERENCES GauBong(MaGauBong),
    SoLuong INT NOT NULL,
    DonGia FLOAT NOT NULL,
    ThanhTien FLOAT NOT NULL
);
GO

-- Tạo bảng ChiTietDonBan để lưu chi tiết của từng đơn hàng bán
CREATE TABLE ChiTietHDB (
    MaChiTietDB INT PRIMARY KEY ,
    MaSP INT FOREIGN KEY REFERENCES GauBong(MaGauBong),
    SoLuong INT NOT NULL,
    DonGia FLOAT NOT NULL,
    ThanhTien FLOAT NOT NULL
);
GO
